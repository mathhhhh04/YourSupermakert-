import sqlite3
import tkinter as tk
from tkinter import messagebox, ttk

# Função para conectar ao banco de dados
def connect_db():
    return sqlite3.connect('preco.db')  # Certifique-se de que o nome do arquivo do banco de dados está correto

# Função para buscar preços de um produto
def buscar_precos():
    nome_produto = entry_product_name.get()

    if not nome_produto:
        messagebox.showerror("Erro", "Por favor, digite o nome de um produto.")
        return

    conn = connect_db()
    cursor = conn.cursor()

    try:
        # Consulta de preços
        cursor.execute("""
            WITH MelhoresPrecos AS (
                SELECT
                    a.id_produto,
                    a.nome AS nome_produto,
                    b.id_supermercado,
                    c.nome AS nome_supermercado,
                    c.endereco AS endereco_supermercado,
                    b.preco,
                    ROW_NUMBER() OVER(PARTITION BY a.id_produto ORDER BY b.preco) AS rank_preco
                FROM
                    Produto a
                INNER JOIN
                    Cotacao b ON a.id_produto = b.id_produto
                INNER JOIN
                    Supermercado c ON b.id_supermercado = c.id_supermercado
                WHERE
                    a.nome = ?
            )
            SELECT id_produto, nome_produto, id_supermercado, nome_supermercado, endereco_supermercado, preco, rank_preco
            FROM MelhoresPrecos
            ORDER BY preco ASC;
        """, (nome_produto,))
        
        precos = cursor.fetchall()

        if precos:
            # Supermercado mais barato
            resultados = f"Produto: {precos[0][1]}\n\nO produto está mais barato no supermercado abaixo:\n"
            resultados += f"Supermercado: {precos[0][3]}\nEndereço: {precos[0][4]}\nPreço: R${precos[0][5]:.2f}\n\n"
            
            # Outros preços
            if len(precos) > 1:
                resultados += "Outros preços encontrados:\n"
                for row in precos[1:]:  # Ignora o primeiro resultado já mostrado como mais barato
                    resultados += f"Supermercado: {row[3]}\nEndereço: {row[4]}\nPreço: R${row[5]:.2f}\n\n"
                    
            messagebox.showinfo("Preços Encontrados", resultados)
        else:
            messagebox.showerror("Erro", "Nenhum preço encontrado para o produto especificado.")
    except sqlite3.Error as e:
        messagebox.showerror("Erro", f"Erro ao buscar preços: {str(e)}")
    finally:
        conn.close()

# Configuração da interface gráfica do usuário com Tkinter
app = tk.Tk()
app.title("Consulta de Preços")

tk.Label(app, text="Nome do Produto").grid(row=0, column=0)
entry_product_name = tk.Entry(app)
entry_product_name.grid(row=0, column=1)

btn_search = tk.Button(app, text="Buscar Preços", command=buscar_precos)
btn_search.grid(row=1, columnspan=2)

app.mainloop()
