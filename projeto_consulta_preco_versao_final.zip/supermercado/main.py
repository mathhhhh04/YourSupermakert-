import sqlite3
import tkinter as tk
from tkinter import messagebox

# Função para conectar ao banco de dados
def connect_db():
    return sqlite3.connect('preco.db')  # Certifique-se de que o nome do arquivo do banco de dados está correto

# Função para procurar produto
def consulta_produto():
    nome_produto = entry_product_name.get()

    conn = connect_db()
    cursor = conn.cursor()

    try:
        # Procurar produto pelo nome usando parâmetros
        cursor.execute("""
                        SELECT a.id_produto, a.nome AS nome_produto, a.categoria, a.marca, 
                            b.id_supermercado, MIN(b.preco) AS menor_preco, c.*
                        FROM Produto AS a
                        INNER JOIN Cotacao AS b ON a.id_produto = b.id_produto
                        INNER JOIN Supermercado AS c ON b.id_supermercado = c.id_supermercado
                        WHERE a.nome = ?
                        GROUP BY a.id_produto
                        ORDER BY a.id_produto
                    """, (nome_produto,))
        product = cursor.fetchone()

        if product:
            product_info = (
                f"ID: {product[0]}\n"
                f"Nome: {product[1]}\n"
                f"Categoria: {product[2]}\n"
                f"Marca: {product[3]}\n"
                f"Menor Preço: R${product[5]:.2f}\n"
                f"Supermercado: {product[7]}\n"
                f"Endereço: {product[8]}\n"
                f"Telefone: {product[9]}\n"
                f"Região: {product[10]}\n"
                f"Cidade: {product[11]}"
            )
            messagebox.showinfo("Produto encontrado", product_info)
        else:
            messagebox.showerror("Erro", "Produto não encontrado")
    except sqlite3.OperationalError as e:
        # Capturar o erro de tabela não encontrada e listar tabelas existentes
        if "no such table" in str(e):
            cursor.execute("SELECT name FROM sqlite_master WHERE type='table';")
            tables = cursor.fetchall()
            table_list = "\n".join([table[0] for table in tables])
            messagebox.showerror("Erro", f"Tabela 'Produto' não encontrada. Tabelas existentes:\n{table_list}")
        else:
            raise e
    finally:
        conn.close()

# Configuração da interface gráfica do usuário com Tkinter
app = tk.Tk()
app.title("Sistema de Busca de Produto")

tk.Label(app, text="Nome do Produto").grid(row=0, column=0)
entry_product_name = tk.Entry(app)
entry_product_name.grid(row=0, column=1)

btn_search = tk.Button(app, text="Buscar", command=consulta_produto)
btn_search.grid(row=1, columnspan=2)

app.mainloop()
