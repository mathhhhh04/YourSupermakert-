import sqlite3
import tkinter as tk
from tkinter import messagebox, ttk

# Função para conectar ao banco de dados
def connect_db():
    return sqlite3.connect('preco.db')  # Certifique-se de que o nome do arquivo do banco de dados está correto

# Função para inserir novo supermercado
def inserir_supermercado(nome_supermercado, endereco_supermercado, telefone_supermercado, regiao_supermercado, cidade_supermercado):
    conn = connect_db()
    cursor = conn.cursor()
    try:
        cursor.execute("""
            INSERT INTO Supermercado (nome, endereco, telefone, regiao, cidade) 
            VALUES (?, ?, ?, ?, ?)
        """, (nome_supermercado, endereco_supermercado, telefone_supermercado, regiao_supermercado, cidade_supermercado))
        conn.commit()
        messagebox.showinfo("Sucesso", f"Supermercado '{nome_supermercado}' cadastrado com sucesso!")
    except sqlite3.Error as e:
        conn.rollback()
        messagebox.showerror("Erro", f"Erro ao cadastrar supermercado: {str(e)}")
    finally:
        conn.close()

# Função para inserir novo produto
def inserir_produto(nome_produto, categoria_produto, marca_produto):
    conn = connect_db()
    cursor = conn.cursor()
    try:
        cursor.execute("""
            INSERT INTO Produto (nome, categoria, marca) 
            VALUES (?, ?, ?)
        """, (nome_produto, categoria_produto, marca_produto))
        conn.commit()
        messagebox.showinfo("Sucesso", f"Produto '{nome_produto}' cadastrado com sucesso!")
    except sqlite3.Error as e:
        conn.rollback()
        messagebox.showerror("Erro", f"Erro ao cadastrar produto: {str(e)}")
    finally:
        conn.close()

# Função para inserir nova cotação
def inserir_cotacao():
    nome_supermercado = entry_supermarket_name.get()
    endereco_supermercado = entry_supermarket_address.get()
    telefone_supermercado = entry_supermarket_phone.get()
    regiao_supermercado = entry_supermarket_region.get()
    cidade_supermercado = entry_supermarket_city.get()

    nome_produto = entry_product_name.get()
    categoria_produto = entry_product_category.get()
    marca_produto = entry_product_brand.get()

    preco = entry_price.get()
    data_cotacao = entry_date.get()

    if not (nome_supermercado and endereco_supermercado and telefone_supermercado and regiao_supermercado and cidade_supermercado):
        messagebox.showerror("Erro", "Todos os campos do supermercado são obrigatórios.")
        return

    if not (nome_produto and categoria_produto and marca_produto):
        messagebox.showerror("Erro", "Todos os campos do produto são obrigatórios.")
        return

    if not (preco and data_cotacao):
        messagebox.showerror("Erro", "Preço e data da cotação são obrigatórios.")
        return

    conn = connect_db()
    cursor = conn.cursor()

    try:
        # Verificar se o supermercado existe ou é novo
        cursor.execute("SELECT id_supermercado FROM Supermercado WHERE nome = ?", (nome_supermercado,))
        result = cursor.fetchone()
        if result:
            id_supermercado = result[0]
        else:
            # Caso o supermercado seja novo, cadastrá-lo
            inserir_supermercado(nome_supermercado, endereco_supermercado, telefone_supermercado, regiao_supermercado, cidade_supermercado)
            cursor.execute("SELECT id_supermercado FROM Supermercado WHERE nome = ?", (nome_supermercado,))
            id_supermercado = cursor.fetchone()[0]

        # Verificar se o produto existe ou é novo
        cursor.execute("SELECT id_produto FROM Produto WHERE nome = ?", (nome_produto,))
        result = cursor.fetchone()
        if result:
            id_produto = result[0]
        else:
            # Caso o produto seja novo, cadastrá-lo
            inserir_produto(nome_produto, categoria_produto, marca_produto)
            cursor.execute("SELECT id_produto FROM Produto WHERE nome = ?", (nome_produto,))
            id_produto = cursor.fetchone()[0]

        # Inserir a nova cotação
        cursor.execute("""
                        INSERT INTO Cotacao (id_usuario, id_supermercado, id_produto, preco, data_cotacao)
                        VALUES (?, ?, ?, ?, ?)
                       """, (1, id_supermercado, id_produto, preco, data_cotacao))  # Supondo que id_usuario = 1 (usuário padrão)

        conn.commit()
        messagebox.showinfo("Cotação Inserida", "Nova cotação inserida com sucesso!")
    except sqlite3.Error as e:
        conn.rollback()
        messagebox.showerror("Erro", f"Erro ao inserir cotação: {str(e)}")
    finally:
        conn.close()

# Configuração da interface gráfica do usuário com Tkinter
app = tk.Tk()
app.title("Inserir Nova Cotação")

# Labels e campos de entrada para Supermercado
tk.Label(app, text="Nome do Supermercado").grid(row=0, column=0)
entry_supermarket_name = tk.Entry(app)
entry_supermarket_name.grid(row=0, column=1)

tk.Label(app, text="Endereço do Supermercado").grid(row=1, column=0)
entry_supermarket_address = tk.Entry(app)
entry_supermarket_address.grid(row=1, column=1)

tk.Label(app, text="Telefone do Supermercado").grid(row=2, column=0)
entry_supermarket_phone = tk.Entry(app)
entry_supermarket_phone.grid(row=2, column=1)

tk.Label(app, text="Região do Supermercado").grid(row=3, column=0)
entry_supermarket_region = tk.Entry(app)
entry_supermarket_region.grid(row=3, column=1)

tk.Label(app, text="Cidade do Supermercado").grid(row=4, column=0)
entry_supermarket_city = tk.Entry(app)
entry_supermarket_city.grid(row=4, column=1)

# Labels e campos de entrada para Produto
tk.Label(app, text="Nome do Produto").grid(row=5, column=0)
entry_product_name = tk.Entry(app)
entry_product_name.grid(row=5, column=1)

tk.Label(app, text="Categoria do Produto").grid(row=6, column=0)
entry_product_category = tk.Entry(app)
entry_product_category.grid(row=6, column=1)

tk.Label(app, text="Marca do Produto").grid(row=7, column=0)
entry_product_brand = tk.Entry(app)
entry_product_brand.grid(row=7, column=1)

# Labels e campos de entrada para Cotação
tk.Label(app, text="Preço").grid(row=8, column=0)
entry_price = tk.Entry(app)
entry_price.grid(row=8, column=1)

tk.Label(app, text="Data da Cotação (AAAA-MM-DD)").grid(row=9, column=0)
entry_date = tk.Entry(app)
entry_date.grid(row=9, column=1)

btn_insert = tk.Button(app, text="Inserir Cotação", command=inserir_cotacao)
btn_insert.grid(row=10, columnspan=2)

app.mainloop()
