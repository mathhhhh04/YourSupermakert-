import sqlite3
import tkinter as tk
from tkinter import messagebox, ttk

# Função para conectar ao banco de dados
def connect_db():
    return sqlite3.connect('preco.db')  # Certifique-se de que o nome do arquivo do banco de dados está correto

# Função para buscar todos os supermercados
def buscar_supermercados():
    conn = connect_db()
    cursor = conn.cursor()
    cursor.execute("SELECT id_supermercado, nome FROM Supermercado")
    supermercados = cursor.fetchall()
    conn.close()
    return supermercados

# Função para buscar todos os produtos
def buscar_produtos():
    conn = connect_db()
    cursor = conn.cursor()
    cursor.execute("SELECT id_produto, nome FROM Produto")
    produtos = cursor.fetchall()
    conn.close()
    return produtos

# Função para inserir novo supermercado
def inserir_supermercado(nome_supermercado):
    conn = connect_db()
    cursor = conn.cursor()
    try:
        cursor.execute("INSERT INTO Supermercado (nome) VALUES (?)", (nome_supermercado,))
        conn.commit()
        messagebox.showinfo("Sucesso", f"Supermercado '{nome_supermercado}' cadastrado com sucesso!")
    except sqlite3.Error as e:
        conn.rollback()
        messagebox.showerror("Erro", f"Erro ao cadastrar supermercado: {str(e)}")
    finally:
        conn.close()

# Função para inserir novo produto
def inserir_produto(nome_produto):
    conn = connect_db()
    cursor = conn.cursor()
    try:
        cursor.execute("INSERT INTO Produto (nome) VALUES (?)", (nome_produto,))
        conn.commit()
        messagebox.showinfo("Sucesso", f"Produto '{nome_produto}' cadastrado com sucesso!")
    except sqlite3.Error as e:
        conn.rollback()
        messagebox.showerror("Erro", f"Erro ao cadastrar produto: {str(e)}")
    finally:
        conn.close()

# Função para inserir nova cotação
def inserir_cotacao():
    supermercado_selecionado = combo_supermercado.get()
    produto_selecionado = combo_produto.get()
    preco = entry_price.get()
    data_cotacao = entry_date.get()

    if not supermercado_selecionado or not produto_selecionado or not preco or not data_cotacao:
        messagebox.showerror("Erro", "Todos os campos são obrigatórios.")
        return

    conn = connect_db()
    cursor = conn.cursor()

    try:
        # Verificar se o supermercado existe ou é novo
        cursor.execute("SELECT id_supermercado FROM Supermercado WHERE nome = ?", (supermercado_selecionado,))
        result = cursor.fetchone()
        if result:
            id_supermercado = result[0]
        else:
            # Caso o supermercado seja novo, cadastrá-lo
            inserir_supermercado(supermercado_selecionado)
            cursor.execute("SELECT id_supermercado FROM Supermercado WHERE nome = ?", (supermercado_selecionado,))
            id_supermercado = cursor.fetchone()[0]

        # Verificar se o produto existe ou é novo
        cursor.execute("SELECT id_produto FROM Produto WHERE nome = ?", (produto_selecionado,))
        result = cursor.fetchone()
        if result:
            id_produto = result[0]
        else:
            # Caso o produto seja novo, cadastrá-lo
            inserir_produto(produto_selecionado)
            cursor.execute("SELECT id_produto FROM Produto WHERE nome = ?", (produto_selecionado,))
            id_produto = cursor.fetchone()[0]

        # Inserir a nova cotação
        cursor.execute("""
                        INSERT INTO Cotacao (id_usuario, id_supermercado, id_produto, preco, data_cotacao)
                        VALUES (?, ?, ?, ?, ?)
                       """, (1, id_supermercado, id_produto, preco, data_cotacao))  # Supondo que id_usuario = 1 (usuário padrão)

        conn.commit()
        messagebox.showinfo("Cotação Inserida", "Nova cotação inserida com sucesso!")
    except sqlite3.Error as e:
        conn.rollback()
        messagebox.showerror("Erro", f"Erro ao inserir cotação: {str(e)}")
    finally:
        conn.close()

# Configuração da interface gráfica do usuário com Tkinter
app = tk.Tk()
app.title("Inserir Nova Cotação")

# Labels e campos de entrada
tk.Label(app, text="Supermercado").grid(row=0, column=0)
combo_supermercado = ttk.Combobox(app, state="readonly", width=30)
combo_supermercado.grid(row=0, column=1)
combo_supermercado['values'] = [f"{nome}" for _, nome in buscar_supermercados()]
combo_supermercado.current(0)

tk.Label(app, text="Produto").grid(row=1, column=0)
combo_produto = ttk.Combobox(app, state="readonly", width=30)
combo_produto.grid(row=1, column=1)
combo_produto['values'] = [f"{nome}" for _, nome in buscar_produtos()]
combo_produto.current(0)

tk.Label(app, text="Preço").grid(row=2, column=0)
entry_price = tk.Entry(app)
entry_price.grid(row=2, column=1)

tk.Label(app, text="Data da Cotação (AAAA-MM-DD)").grid(row=3, column=0)
entry_date = tk.Entry(app)
entry_date.grid(row=3, column=1)

btn_insert = tk.Button(app, text="Inserir Cotação", command=inserir_cotacao)
btn_insert.grid(row=4, columnspan=2)

app.mainloop()
