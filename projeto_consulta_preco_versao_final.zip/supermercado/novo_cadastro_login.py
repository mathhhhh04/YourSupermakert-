import sqlite3
import tkinter as tk
from tkinter import messagebox, ttk

# Função para conectar ao banco de dados
def connect_db():
    return sqlite3.connect('preco.db')  # Certifique-se de que o nome do arquivo do banco de dados está correto

# Função para verificar o login
def verificar_login(email, senha):
    conn = connect_db()
    cursor = conn.cursor()
    cursor.execute("SELECT id_usuario, nome FROM Usuario WHERE email = ? AND senha = ?", (email, senha))
    user = cursor.fetchone()
    conn.close()
    return user  # Retorna (id_usuario, nome) se o login for válido, None caso contrário

# Função para inserir novo supermercado
def inserir_supermercado(nome_supermercado, endereco_supermercado, telefone_supermercado, regiao_supermercado, cidade_supermercado):
    conn = connect_db()
    cursor = conn.cursor()
    try:
        cursor.execute("""
            INSERT INTO Supermercado (nome, endereco, telefone, regiao, cidade) 
            VALUES (?, ?, ?, ?, ?)
        """, (nome_supermercado, endereco_supermercado, telefone_supermercado, regiao_supermercado, cidade_supermercado))
        conn.commit()
        messagebox.showinfo("Sucesso", f"Supermercado '{nome_supermercado}' cadastrado com sucesso!")
    except sqlite3.Error as e:
        conn.rollback()
        messagebox.showerror("Erro", f"Erro ao cadastrar supermercado: {str(e)}")
    finally:
        conn.close()

# Função para inserir nova cotação
def inserir_cotacao():
    supermercado_selecionado = entry_supermarket_name.get()
    produto_selecionado = entry_product_name.get()
    preco = entry_price.get()
    data_cotacao = entry_date.get()

    if not (supermercado_selecionado and produto_selecionado and preco and data_cotacao):
        messagebox.showerror("Erro", "Todos os campos são obrigatórios.")
        return

    conn = connect_db()
    cursor = conn.cursor()

    try:
        # Verificar se o supermercado existe ou é novo
        cursor.execute("SELECT id_supermercado FROM Supermercado WHERE nome = ?", (supermercado_selecionado,))
        result = cursor.fetchone()
        if result:
            id_supermercado = result[0]
        else:
            # Caso o supermercado seja novo, cadastrá-lo
            endereco_supermercado = entry_supermarket_address.get()
            telefone_supermercado = entry_supermarket_phone.get()
            regiao_supermercado = entry_supermarket_region.get()
            cidade_supermercado = entry_supermarket_city.get()
            inserir_supermercado(supermercado_selecionado, endereco_supermercado, telefone_supermercado, regiao_supermercado, cidade_supermercado)
            cursor.execute("SELECT id_supermercado FROM Supermercado WHERE nome = ?", (supermercado_selecionado,))
            id_supermercado = cursor.fetchone()[0]

        # Verificar se o produto existe ou é novo
        cursor.execute("SELECT id_produto FROM Produto WHERE nome = ?", (produto_selecionado,))
        result = cursor.fetchone()
        if result:
            id_produto = result[0]
        else:
            # Caso o produto seja novo, cadastrá-lo (exemplo simples)
            categoria_produto = "Categoria padrão"  # Preencher com lógica de obtenção de categoria
            marca_produto = "Marca padrão"          # Preencher com lógica de obtenção de marca
            cursor.execute("""
                INSERT INTO Produto (nome, categoria, marca) 
                VALUES (?, ?, ?)
            """, (produto_selecionado, categoria_produto, marca_produto))
            conn.commit()
            cursor.execute("SELECT id_produto FROM Produto WHERE nome = ?", (produto_selecionado,))
            id_produto = cursor.fetchone()[0]

        # Inserir a nova cotação
        # Supondo que id_usuario_logado esteja definido globalmente após o login
        cursor.execute("""
                        INSERT INTO Cotacao (id_usuario, id_supermercado, id_produto, preco, data_cotacao)
                        VALUES (?, ?, ?, ?, ?)
                       """, (id_usuario_logado, id_supermercado, id_produto, preco, data_cotacao))

        conn.commit()
        messagebox.showinfo("Cotação Inserida", "Nova cotação inserida com sucesso!")
    except sqlite3.Error as e:
        conn.rollback()
        messagebox.showerror("Erro", f"Erro ao inserir cotação: {str(e)}")
    finally:
        conn.close()

# Função para processar o login
def processar_login():
    email = entry_email.get()
    senha = entry_senha.get()

    if not email or not senha:
        messagebox.showerror("Erro", "Por favor, preencha todos os campos.")
        return

    # Verificar login
    user = verificar_login(email, senha)
    if user:
        global id_usuario_logado
        id_usuario_logado = user[0]
        messagebox.showinfo("Sucesso", f"Bem-vindo, {user[1]}!")
        abrir_janela_inserir_cotacao()
    else:
        messagebox.showerror("Erro", "Email ou senha incorretos.")

# Função para abrir a janela de inserção de cotação após o login
def abrir_janela_inserir_cotacao():
    # Fechar a janela de login
    app_login.withdraw()

    # Criar nova janela para inserir cotação
    app = tk.Tk()
    app.title("Inserir Nova Cotação")

    # Labels e campos de entrada
    tk.Label(app, text="Nome do Supermercado").grid(row=0, column=0)
    global entry_supermarket_name
    entry_supermarket_name = tk.Entry(app)
    entry_supermarket_name.grid(row=0, column=1)

    tk.Label(app, text="Endereço do Supermercado").grid(row=1, column=0)
    global entry_supermarket_address
    entry_supermarket_address = tk.Entry(app)
    entry_supermarket_address.grid(row=1, column=1)

    tk.Label(app, text="Telefone do Supermercado").grid(row=2, column=0)
    global entry_supermarket_phone
    entry_supermarket_phone = tk.Entry(app)
    entry_supermarket_phone.grid(row=2, column=1)

    tk.Label(app, text="Região do Supermercado").grid(row=3, column=0)
    global entry_supermarket_region
    entry_supermarket_region = tk.Entry(app)
    entry_supermarket_region.grid(row=3, column=1)

    tk.Label(app, text="Cidade do Supermercado").grid(row=4, column=0)
    global entry_supermarket_city
    entry_supermarket_city = tk.Entry(app)
    entry_supermarket_city.grid(row=4, column=1)

    tk.Label(app, text="Nome do Produto").grid(row=5, column=0)
    global entry_product_name
    entry_product_name = tk.Entry(app)
    entry_product_name.grid(row=5, column=1)

    tk.Label(app, text="Preço").grid(row=6, column=0)
    global entry_price
    entry_price = tk.Entry(app)
    entry_price.grid(row=6, column=1)

    tk.Label(app, text="Data da Cotação (AAAA-MM-DD)").grid(row=7, column=0)
    global entry_date
    entry_date = tk.Entry(app)
    entry_date.grid(row=7, column=1)

    btn_insert = tk.Button(app, text="Inserir Cotação", command=inserir_cotacao)
    btn_insert.grid(row=8, columnspan=2)

    app.mainloop()

# Configuração da interface gráfica do usuário com Tkinter para a tela de login
app_login = tk.Tk()
app_login.title("Login")

tk.Label(app_login, text="Email").grid(row=0, column=0)
entry_email = tk.Entry(app_login)
entry_email.grid(row=0, column=1)

tk.Label(app_login, text="Senha").grid(row=1, column=0)
entry_senha = tk.Entry(app_login, show="*")
entry_senha.grid(row=1, column=1)

btn_login = tk.Button(app_login, text="Login", command=processar_login)
btn_login.grid(row=2, columnspan=2)

app_login.mainloop()
