import sqlite3
import tkinter as tk
from tkinter import ttk, messagebox

# Função para conectar ao banco de dados
def connect_db():
    return sqlite3.connect('preco.db')  # Certifique-se de que o nome do arquivo do banco de dados está correto

# Função para executar consulta SELECT
def executar_consulta():
    query = entry_query.get("1.0", tk.END)  # Obter a consulta SQL do campo de texto

    if not query.strip():
        messagebox.showerror("Erro", "Por favor, insira uma consulta SQL.")
        return

    conn = connect_db()
    cursor = conn.cursor()

    try:
        cursor.execute(query)
        rows = cursor.fetchall()

        # Exibir resultados em uma nova janela
        mostrar_resultados(rows)
    except sqlite3.Error as e:
        messagebox.showerror("Erro", f"Erro ao executar a consulta: {str(e)}")
    finally:
        conn.close()

# Função para exibir os resultados da consulta em uma nova janela
def mostrar_resultados(rows):
    if not rows:
        messagebox.showinfo("Resultado da Consulta", "Nenhum resultado encontrado.")
        return

    # Criar uma nova janela para exibir os resultados
    result_window = tk.Toplevel()
    result_window.title("Resultado da Consulta")

    # Criar uma Treeview para mostrar os resultados
    tree = ttk.Treeview(result_window)
    tree["columns"] = list(range(len(rows[0])))  # Colunas baseadas no número de colunas retornadas

    # Definir cabeçalhos das colunas
    for i in range(len(rows[0])):
        tree.heading(i, text=f"Coluna {i+1}")

    # Inserir os dados das linhas
    for row in rows:
        tree.insert("", tk.END, values=row)

    tree.pack(expand=tk.YES, fill=tk.BOTH)

# Configuração da interface gráfica do usuário com Tkinter
app = tk.Tk()
app.title("Consulta SQL")

# Campo de texto para a consulta SQL
entry_query = tk.Text(app, width=60, height=10)
entry_query.grid(row=0, column=0, padx=10, pady=10, columnspan=2)

# Botão para executar a consulta
btn_execute = tk.Button(app, text="Executar Consulta", command=executar_consulta)
btn_execute.grid(row=1, column=0, padx=10, pady=10)

# Botão para sair do programa
btn_exit = tk.Button(app, text="Sair", command=app.quit)
btn_exit.grid(row=1, column=1, padx=10, pady=10)

app.mainloop()
