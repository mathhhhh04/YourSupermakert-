import sqlite3
import tkinter as tk
from tkinter import messagebox, ttk

# Função para conectar ao banco de dados
def connect_db():
    return sqlite3.connect('preco.db')  # Certifique-se de que o nome do arquivo do banco de dados está correto

# Função para buscar todos os supermercados
def buscar_supermercados():
    conn = connect_db()
    cursor = conn.cursor()
    cursor.execute("SELECT id_supermercado, nome, endereco FROM Supermercado")
    supermercados = cursor.fetchall()
    conn.close()
    return supermercados

# Função para buscar todos os produtos
def buscar_produtos():
    conn = connect_db()
    cursor = conn.cursor()
    cursor.execute("SELECT id_produto, nome FROM Produto")
    produtos = cursor.fetchall()
    conn.close()
    return produtos

# Função para inserir nova cotação
def calcular_compra():
    produtos_quantidades = []

    for i in range(len(entries_produtos)):
        produto = entries_produtos[i][0].get()
        quantidade = entries_produtos[i][1].get()
        if produto and quantidade:
            produtos_quantidades.append((produto, int(quantidade)))

    if not produtos_quantidades:
        messagebox.showerror("Erro", "Por favor, insira pelo menos um produto com quantidade.")
        return

    conn = connect_db()
    cursor = conn.cursor()

    try:
        # Buscar todos os supermercados com seus endereços
        supermercados = buscar_supermercados()

        resultados = []
        for supermercado in supermercados:
            id_supermercado = supermercado[0]
            nome_supermercado = supermercado[1]
            endereco_supermercado = supermercado[2]

            valor_total = 0
            for produto, quantidade in produtos_quantidades:
                cursor.execute("""
                    SELECT b.preco
                    FROM Produto a
                    INNER JOIN Cotacao b ON a.id_produto = b.id_produto
                    WHERE a.nome = ? AND b.id_supermercado = ?
                """, (produto, id_supermercado))
                precos = cursor.fetchall()

                if precos:
                    preco_produto = precos[0][0]  # Vamos considerar apenas o primeiro preço encontrado
                    valor_total += preco_produto * quantidade

            resultados.append((nome_supermercado, endereco_supermercado, valor_total))

        # Encontrar o supermercado com o valor total mais baixo
        resultados.sort(key=lambda x: x[2])  # Ordenar por valor total
        supermercado_mais_barato = resultados[0][0]
        endereco_mais_barato = resultados[0][1]
        valor_mais_barato = resultados[0][2]

        # Preparar mensagem de resultado
        mensagem = f"Valor total da compra:\n\n"
        mensagem += f"No supermercado '{supermercado_mais_barato}' foi encontrado o menor valor:\n"
        mensagem += f"Endereço: {endereco_mais_barato}\n"
        mensagem += f"Valor Total: R${valor_mais_barato:.2f}\n\n"

        mensagem += "Outros supermercados:\n"
        for i, (supermercado, endereco, valor) in enumerate(resultados[1:], start=1):
            mensagem += f"\nSupermercado: {supermercado}\n"
            mensagem += f"Endereço: {endereco}\n"
            mensagem += f"Valor Total: R${valor:.2f}\n"
            if i < len(resultados) - 1:
                mensagem += "\n"  # Adicionar linha em branco entre os supermercados

        messagebox.showinfo("Resultado da Consulta", mensagem)
    except sqlite3.Error as e:
        messagebox.showerror("Erro", f"Erro ao calcular compra: {str(e)}")
    finally:
        conn.close()

# Configuração da interface gráfica do usuário com Tkinter
app = tk.Tk()
app.title("Consulta de Preços por Quantidade")

# Labels e campos de entrada para Produto e Quantidade
tk.Label(app, text="Produto").grid(row=0, column=0)
tk.Label(app, text="Quantidade").grid(row=0, column=1)

entries_produtos = []
for i in range(5):  # Permitindo até 5 produtos
    entry_produto = ttk.Combobox(app, state="readonly", width=30)
    entry_produto.grid(row=i + 1, column=0)
    entry_produto['values'] = [nome for _, nome in buscar_produtos()]
    entry_produto.current(0)

    entry_quantidade = tk.Entry(app, width=10)
    entry_quantidade.grid(row=i + 1, column=1)

    entries_produtos.append((entry_produto, entry_quantidade))

# Botão para calcular compra
btn_calcular = tk.Button(app, text="Calcular Compra", command=calcular_compra)
btn_calcular.grid(row=7, columnspan=2)

app.mainloop()
